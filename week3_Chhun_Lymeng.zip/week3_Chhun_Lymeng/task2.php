

<?php



    function odd($var)
{
    // returns whether the input integer is odd
    return $var & 1;
}

function even($var)
{
    // returns whether the input integer is even
    return !($var & 1);
}


$arr = [2,3,4,6,7,9,11,20];

echo "Odd :<br>";
print_r(array_filter($arr, "odd"));
echo "<br>Even:<br>";
print_r(array_filter($arr, "even"));


?>