<?php
echo nl2br("Task 1\n",true);

$str = "emocleW ot PHP";

$i = strlen($str) - 1;
    for($i ;$i >= 0; $i--){
            
       echo $str[$i];
    }
  
?>